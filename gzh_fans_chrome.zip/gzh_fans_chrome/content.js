// 微信公众号信息查询插件 - Content Script
// 插件作者「公众号：刘坏坏」

class WeChatQueryTool {
  constructor() {
    this.init();
  }

  init() {
    // 检查MD5库是否加载
    this.checkMD5Library();
    
    // 检查是否是首次安装
    this.checkFirstInstall();
    
    // 初始化查询次数
    this.initQueryCount();
    
    // 等待页面完全加载后再创建按钮
    this.waitForCreationMenu(() => {
        // 创建按钮和模态框
        this.createQueryButton();
        this.createModal();
        this.bindEvents();
    });
  }

  // 检查MD5库是否加载
  checkMD5Library() {
    if (typeof md5 === 'undefined') {
      console.error('MD5库未加载，充值功能可能无法正常工作');
      // 可以在这里添加备用方案或错误处理
    } else {
      console.log('MD5库加载成功');
    }
  }

  // 等待"新的创作"菜单加载完成
  waitForCreationMenu(callback) {
    const checkMenu = () => {
      const creationMenu = document.querySelector('.new-creation__menu');
      if (creationMenu) {
        callback();
      } else {
        setTimeout(checkMenu, 100);
      }
    };
    checkMenu();
  }

  // 创建查询按钮
  createQueryButton() {
    const creationMenu = document.querySelector('.new-creation__menu');
    if (!creationMenu) {
      return;
    }

    // 检查是否已经存在查询按钮
    const existingButton = creationMenu.querySelector('.wx-query-menu-item');
    if (existingButton) {
      return;
    }

    // 创建新的菜单项
    const menuItem = document.createElement('div');
    menuItem.className = 'new-creation__menu-item wx-query-menu-item';
    menuItem.innerHTML = `
      <div class="new-creation__menu-content">
        <i class="new-creation__icon wx-query-icon">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="11" cy="11" r="8"></circle>
            <path d="m21 21-4.35-4.35"></path>
          </svg>
        </i>
        <div class="new-creation__menu-title">对标信息</div>
      </div>
    `;

    // 将按钮插入到"新的创作"菜单中
    creationMenu.appendChild(menuItem);
    this.queryButton = menuItem;
  }

  // 创建模态框
  createModal() {
    const modal = document.createElement('div');
    modal.className = 'wx-query-modal';
    modal.innerHTML = `
      <div class="wx-query-modal-content">
        <div class="wx-query-modal-header">
          <h3 class="wx-query-modal-title">微信公众号信息查询</h3>
          <button class="wx-query-close-btn">&times;</button>
        </div>
        
        <div class="wx-query-input-group">
          <label class="wx-query-label">公众号名称</label>
          <input type="text" class="wx-query-input" placeholder="请输入要查询的公众号名称" />
        </div>
        
        <button class="wx-query-submit-btn">开始查询</button>
        
        <div id="queryResult"></div>
        
        <div class="wx-query-status-bar">
          <span class="wx-query-status-text">剩余查询次数: 5次</span>
          <button class="wx-query-recharge-btn">去充值</button>
        </div>
        
        <div class="wx-query-footer">
          作者公众号：刘坏坏
        </div>
      </div>
    `;
    document.body.appendChild(modal);
    this.modal = modal;
    this.modalContent = modal.querySelector('.wx-query-modal-content');
    this.closeBtn = modal.querySelector('.wx-query-close-btn');
    this.input = modal.querySelector('.wx-query-input');
    this.submitBtn = modal.querySelector('.wx-query-submit-btn');
    this.resultDiv = modal.querySelector('#queryResult');
    this.rechargeBtn = modal.querySelector('.wx-query-recharge-btn');
  }

  // 绑定事件
  bindEvents() {
    // 打开模态框
    if (this.queryButton) {
      this.queryButton.addEventListener('click', () => {
        this.showModal();
      });
    }

    // 关闭模态框
    if (this.closeBtn) {
      this.closeBtn.addEventListener('click', () => {
        this.hideModal();
      });
    }

    // 点击背景关闭模态框
    if (this.modal) {
      this.modal.addEventListener('click', (e) => {
        if (e.target === this.modal) {
          this.hideModal();
        }
      });
    }

    // 提交查询
    if (this.submitBtn) {
      this.submitBtn.addEventListener('click', () => {
        this.handleQuery();
      });
    }

    // 回车提交
    if (this.input) {
      this.input.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
          this.handleQuery();
        }
      });
    }

    // 去充值按钮
    if (this.rechargeBtn) {
      this.rechargeBtn.addEventListener('click', () => {
        this.showRechargeModal();
      });
    }

    // ESC关闭
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        if (this.modal && this.modal.classList.contains('show')) {
          this.hideModal();
        }
        if (this.rechargeModal && this.rechargeModal.classList.contains('show')) {
          this.hideRechargeModal();
        }
      }
    });
  }

  // 初始化查询次数
  initQueryCount() {
    const countKey = 'wx_query_count';
    const count = localStorage.getItem(countKey);
    
    if (count === null) {
      // 首次使用，给5次免费查询
      localStorage.setItem(countKey, '5');
      this.queryCount = 5;
    } else {
      this.queryCount = parseInt(count);
    }
  }

  // 获取查询次数
  getQueryCount() {
    return this.queryCount || 0;
  }

  // 更新查询次数显示
  updateQueryCountDisplay() {
    const statusText = document.querySelector('.wx-query-status-text');
    const rechargeStatusText = document.querySelector('.wx-recharge-status-text');
    
    if (statusText) {
      statusText.textContent = `剩余查询次数: ${this.queryCount}次`;
    }
    
    if (rechargeStatusText) {
      rechargeStatusText.textContent = `当前剩余次数: ${this.queryCount}次`;
    }
  }

  // 消耗查询次数
  consumeQueryCount() {
    if (this.queryCount > 0) {
      this.queryCount--;
      localStorage.setItem('wx_query_count', this.queryCount.toString());
      this.updateQueryCountDisplay();
      return true;
    }
    return false;
  }

  // 显示模态框
  showModal() {
    this.modal.classList.add('show');
    this.input.value = '';
    this.resultDiv.innerHTML = '';
    this.input.focus();
    // 更新查询次数显示
    this.updateQueryCountDisplay();
  }

  // 隐藏模态框
  hideModal() {
    this.modal.classList.remove('show');
  }

  // 处理查询
  async handleQuery() {
    const query = this.input.value.trim();
    if (!query) {
      this.showError('请输入公众号名称');
      return;
    }

    // 检查查询次数
    if (this.queryCount <= 0) {
      this.showError('查询次数已用完，请充值后继续使用');
      // 延迟跳转到充值页面
      setTimeout(() => {
        this.showRechargeModal();
      }, 1500);
      return;
    }

    this.showLoading();
    this.submitBtn.disabled = true;

    try {
      // 第一步：搜索公众号
      const searchResult = await this.searchAccount(query);
      if (!searchResult || searchResult.list.length === 0) {
        this.showError('未找到相关公众号，请检查名称是否正确');
        return;
      }

      // 取第一个搜索结果
      const account = searchResult.list[0];
      
      // 第二步：获取公众号详细信息
      const detailResult = await this.getAccountDetail(account.fakeid);
      
      // 显示结果
      this.showResult(account, detailResult);
      
      // 查询成功，消耗一次查询次数
      this.consumeQueryCount();
      
    } catch (error) {
      this.showError('查询失败: ' + error.message);
    } finally {
      this.submitBtn.disabled = false;
    }
  }

  // 搜索公众号
  async searchAccount(query) {
    const cookies = await this.getCookies();
    const token = this.extractToken(cookies);
    
    if (!token) {
      throw new Error('未找到有效的token，请确保已登录微信公众平台');
    }

    const url = `https://mp.weixin.qq.com/cgi-bin/searchbiz?action=search_biz&begin=0&count=5&query=${encodeURIComponent(query)}&fingerprint=${this.generateFingerprint()}&token=${token}&lang=zh_CN&f=json&ajax=1`;
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Accept': '*/*',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
        'Referer': window.location.href,
        'Sec-Ch-Ua': '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
        'Sec-Ch-Ua-Mobile': '?0',
        'Sec-Ch-Ua-Platform': '"macOS"',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'User-Agent': navigator.userAgent,
        'X-Requested-With': 'XMLHttpRequest'
      },
      credentials: 'include'
    });

    if (!response.ok) {
      throw new Error(`搜索请求失败: ${response.status}`);
    }

    const data = await response.json();
    
    if (data.base_resp && data.base_resp.ret !== 0) {
      throw new Error(`搜索失败: ${data.base_resp.err_msg}`);
    }

    return data;
  }

  // 获取公众号详细信息
  async getAccountDetail(fakeid) {
    const cookies = await this.getCookies();
    const token = this.extractToken(cookies);
    
    if (!token) {
      throw new Error('未找到有效的token');
    }

    const url = `https://mp.weixin.qq.com/cgi-bin/appmsgpublish?sub=list&search_field=null&begin=0&count=5&query=&fakeid=${encodeURIComponent(fakeid)}&type=101_1&free_publish_type=1&sub_action=list_ex&fingerprint=${this.generateFingerprint()}&token=${token}&lang=zh_CN&f=json&ajax=1`;
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Accept': '*/*',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
        'Referer': window.location.href,
        'Sec-Ch-Ua': '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
        'Sec-Ch-Ua-Mobile': '?0',
        'Sec-Ch-Ua-Platform': '"macOS"',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'User-Agent': navigator.userAgent,
        'X-Requested-With': 'XMLHttpRequest'
      },
      credentials: 'include'
    });

    if (!response.ok) {
      throw new Error(`详情请求失败: ${response.status}`);
    }

    const data = await response.json();
    
    if (data.base_resp && data.base_resp.ret !== 0) {
      throw new Error(`获取详情失败: ${data.base_resp.err_msg}`);
    }

    return data;
  }

  // 获取Cookie
  async getCookies() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({action: 'getCookies'}, (response) => {
        if (chrome.runtime.lastError) {
          resolve('');
        } else {
          resolve(response.cookies || '');
        }
      });
    });
  }

  // 从Cookie中提取token
  extractToken(cookies) {
    // 尝试多种方式提取token
    let token = null;
    
    // 方法1：从cookie字符串中提取
    const match1 = cookies.match(/token=([^;]+)/);
    if (match1) {
      token = match1[1];
    }
    
    // 方法2：尝试从页面URL中提取
    if (!token) {
      const urlParams = new URLSearchParams(window.location.search);
      token = urlParams.get('token');
    }
    
    // 方法3：尝试从页面中的其他元素提取
    if (!token) {
      const scripts = document.querySelectorAll('script');
      for (let script of scripts) {
        const content = script.textContent || script.innerHTML;
        const match2 = content.match(/token['":\s]*['"]([^'"]+)['"]/);
        if (match2) {
          token = match2[1];
          break;
        }
      }
    }
    
    return token;
  }

  // 生成fingerprint（简单的实现）
  generateFingerprint() {
    return '3fec25255d22fd0f735f8ccec90846da'; // 使用示例中的固定值
  }

  // 显示加载状态
  showLoading() {
    this.resultDiv.innerHTML = '<div class="wx-query-loading">正在查询中...</div>';
  }

  // 显示错误信息
  showError(message) {
    this.resultDiv.innerHTML = `<div class="wx-query-error">${message}</div>`;
  }

  // 创建充值模态框
  createRechargeModal() {
    const modal = document.createElement('div');
    modal.className = 'wx-query-modal wx-recharge-modal';
    modal.innerHTML = `
      <div class="wx-query-modal-content">
        <div class="wx-query-modal-header">
          <h3 class="wx-query-modal-title">充值中心</h3>
          <button class="wx-query-close-btn wx-recharge-close-btn">&times;</button>
        </div>
        
        <div class="wx-recharge-status">
          <span class="wx-recharge-status-text">当前剩余次数: 5次</span>
        </div>
        
        <div class="wx-recharge-purchase">
          <span class="wx-recharge-purchase-text">没有充值码？点击购买</span>
          <button class="wx-recharge-purchase-btn" onclick="window.open('https://68n.cn/nZJoj', '_blank')">购买充值码</button>
        </div>
        
        <div class="wx-recharge-input-group">
          <label class="wx-query-label">充值码输入</label>
          <input type="text" class="wx-recharge-input" placeholder="请输入充值码" />
        </div>
        
        <button class="wx-recharge-submit-btn">立即充值</button>
        
        <button class="wx-recharge-back-btn">返回查询</button>
        
        <div class="wx-query-footer">
          作者公众号：刘坏坏
        </div>
      </div>
    `;
    document.body.appendChild(modal);
    this.rechargeModal = modal;
    this.rechargeCloseBtn = modal.querySelector('.wx-recharge-close-btn');
    this.rechargeInput = modal.querySelector('.wx-recharge-input');
    this.rechargeSubmitBtn = modal.querySelector('.wx-recharge-submit-btn');
    this.rechargeBackBtn = modal.querySelector('.wx-recharge-back-btn');
  }

  // 显示充值模态框
  showRechargeModal() {
    if (!this.rechargeModal) {
      this.createRechargeModal();
      this.bindRechargeEvents();
    }
    // 更新充值页面的次数显示
    this.updateQueryCountDisplay();
    this.rechargeModal.classList.add('show');
    this.rechargeInput.value = '';
    this.rechargeInput.focus();
  }

  // 隐藏充值模态框
  hideRechargeModal() {
    if (this.rechargeModal) {
      this.rechargeModal.classList.remove('show');
    }
  }

  // 绑定充值页面事件
  bindRechargeEvents() {
    // 关闭充值模态框
    if (this.rechargeCloseBtn) {
      this.rechargeCloseBtn.addEventListener('click', () => {
        this.hideRechargeModal();
      });
    }

    // 点击背景关闭充值模态框
    if (this.rechargeModal) {
      this.rechargeModal.addEventListener('click', (e) => {
        if (e.target === this.rechargeModal) {
          this.hideRechargeModal();
        }
      });
    }

    // 立即充值按钮
    if (this.rechargeSubmitBtn) {
      this.rechargeSubmitBtn.addEventListener('click', () => {
        this.handleRecharge();
      });
    }

    // 返回查询按钮
    if (this.rechargeBackBtn) {
      this.rechargeBackBtn.addEventListener('click', () => {
        this.hideRechargeModal();
        this.showModal();
      });
    }

    // 回车提交充值码
    if (this.rechargeInput) {
      this.rechargeInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
          this.handleRecharge();
        }
      });
    }
  }

  // 处理充值
  async handleRecharge() {
    const code = this.rechargeInput.value.trim();
    if (!code) {
      this.showToast('请输入充值码', 'error');
      return;
    }

    // 禁用充值按钮，防止重复提交
    this.rechargeSubmitBtn.disabled = true;
    this.rechargeSubmitBtn.textContent = '充值中...';

    try {
      // 验证充值码
      const result = await this.validateRechargeCode(code);
      
      if (result.success) {
        // 充值成功，增加查询次数
        this.addQueryCount(result.count);
        
        // 标记充值码已使用
        this.markRechargeCodeUsed(code);
        
        // 显示成功消息
        this.showRechargeSuccess(result.count);
        
        // 清空输入框
        this.rechargeInput.value = '';
        
        // 延迟返回查询页面
        setTimeout(() => {
          this.hideRechargeModal();
          this.showModal();
        }, 2000);
        
      } else {
        // 充值失败
        this.showToast('充值码无效：' + result.message, 'error');
      }
      
    } catch (error) {
      console.error('充值验证失败:', error);
      this.showToast('充值验证失败，请稍后重试', 'error');
    } finally {
      // 恢复按钮状态
      this.rechargeSubmitBtn.disabled = false;
      this.rechargeSubmitBtn.textContent = '立即充值';
    }
  }

  // 显示Toast提示
  showToast(message, type = 'info') {
    // 移除已存在的toast
    const existingToast = document.querySelector('.wx-query-toast');
    if (existingToast) {
      existingToast.remove();
    }

    // 创建toast元素
    const toast = document.createElement('div');
    toast.className = `wx-query-toast wx-query-toast-${type}`;
    
    // 设置样式
    const colors = {
      success: '#52c41a',
      error: '#ff4d4f',
      info: '#1890ff',
      warning: '#faad14'
    };
    
    toast.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: ${colors[type] || colors.info};
      color: white;
      padding: 12px 20px;
      border-radius: 6px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      z-index: 10000;
      font-size: 14px;
      font-weight: 500;
      max-width: 300px;
      word-wrap: break-word;
      animation: wxToastSlideIn 0.3s ease;
      transition: all 0.3s ease;
    `;
    
    toast.textContent = message;
    
    // 添加动画样式
    if (!document.querySelector('#wxToastStyles')) {
      const style = document.createElement('style');
      style.id = 'wxToastStyles';
      style.textContent = `
        @keyframes wxToastSlideIn {
          from { 
            transform: translate(-50%, -50%) scale(0.8); 
            opacity: 0; 
          }
          to { 
            transform: translate(-50%, -50%) scale(1); 
            opacity: 1; 
          }
        }
        @keyframes wxToastSlideOut {
          from { 
            transform: translate(-50%, -50%) scale(1); 
            opacity: 1; 
          }
          to { 
            transform: translate(-50%, -50%) scale(0.8); 
            opacity: 0; 
          }
        }
      `;
      document.head.appendChild(style);
    }
    
    document.body.appendChild(toast);
    
    // 3秒后自动移除
    setTimeout(() => {
      toast.style.animation = 'wxToastSlideOut 0.3s ease';
      setTimeout(() => {
        if (toast.parentNode) {
          toast.parentNode.removeChild(toast);
        }
      }, 300);
    }, 3000);
  }

  // 验证充值码格式
  validateRechargeCodeFormat(code) {
    // 检查格式：XXXX-XXXXXX-XXXXXX
    const formatRegex = /^[A-Z0-9]{4}-[A-Z0-9]{6}-[A-Z0-9]{6}$/;
    if (!formatRegex.test(code)) {
      return {
        valid: false,
        message: '充值码格式错误，正确格式为：XXXX-XXXXXX-XXXXXX'
      };
    }
    return { valid: true };
  }

  // 验证充值码校验位
  validateRechargeCodeChecksum(code) {
    // 提取校验码和基础字符串
    const parts = code.split('-');
    const checksum = parts[0];
    const baseString = parts[1] + parts[2];
    
    // 重新计算MD5校验码
    const md5Hash = md5(baseString).toUpperCase();
    const expectedChecksum = md5Hash[0] + md5Hash[4] + md5Hash[8] + md5Hash[5];
    
    if (checksum !== expectedChecksum) {
      return {
        valid: false,
        message: '充值码校验失败，可能是无效的充值码'
      };
    }
    
    return { valid: true };
  }

  // 检查充值码是否已使用
  isRechargeCodeUsed(code) {
    const usedCodes = JSON.parse(localStorage.getItem('wx_used_recharge_codes') || '[]');
    return usedCodes.includes(code);
  }

  // 标记充值码已使用
  markRechargeCodeUsed(code) {
    const usedCodes = JSON.parse(localStorage.getItem('wx_used_recharge_codes') || '[]');
    usedCodes.push(code);
    localStorage.setItem('wx_used_recharge_codes', JSON.stringify(usedCodes));
  }

  // 统计字符串中的数字数量
  countDigits(str) {
    return (str.match(/\d/g) || []).length;
  }

  // 根据数字数量获取充值次数
  getRechargeCount(digitCount) {
    switch(digitCount) {
      case 1: return 10;
      case 2: return 50;
      case 3: return 100;
      case 4: return -1; // -1表示不限次数
      default: return 10;
    }
  }

  // 验证充值码
  async validateRechargeCode(code) {
    // 1. 检查格式
    const formatResult = this.validateRechargeCodeFormat(code);
    if (!formatResult.valid) {
      return {
        success: false,
        message: formatResult.message
      };
    }

    // 2. 检查是否已使用
    if (this.isRechargeCodeUsed(code)) {
      return {
        success: false,
        message: '该充值码已被使用'
      };
    }

    // 3. 验证校验码
    const checksumResult = this.validateRechargeCodeChecksum(code);
    if (!checksumResult.valid) {
      return {
        success: false,
        message: checksumResult.message
      };
    }

    // 4. 计算充值次数
    const parts = code.split('-');
    const baseString = parts[1] + parts[2];
    const digitCount = this.countDigits(baseString);
    const rechargeCount = this.getRechargeCount(digitCount);

    return {
      success: true,
      count: rechargeCount,
      digitCount: digitCount,
      baseString: baseString
    };
  }

  // 增加查询次数
  addQueryCount(count) {
    if (count === -1) {
      // 不限次数，设置为一个很大的数
      this.queryCount = 999999;
    } else {
      this.queryCount += count;
    }
    
    // 保存到本地存储
    localStorage.setItem('wx_query_count', this.queryCount.toString());
    
    // 更新显示
    this.updateQueryCountDisplay();
  }

  // 显示充值成功消息
  showRechargeSuccess(count) {
    let message;
    if (count === -1) {
      message = '🎉 充值成功！获得不限次数查询权限！';
    } else {
      message = `🎉 充值成功！获得 ${count} 次查询机会！`;
    }
    
    // 在充值页面显示成功消息
    const successDiv = document.createElement('div');
    successDiv.style.cssText = `
      background: #52c41a;
      color: white;
      padding: 16px;
      border-radius: 8px;
      text-align: center;
      margin: 16px 0;
      font-size: 16px;
      font-weight: 500;
      animation: slideIn 0.3s ease;
    `;
    successDiv.textContent = message;
    
    // 插入到充值按钮前面
    const rechargeBtn = this.rechargeModal.querySelector('.wx-recharge-submit-btn');
    rechargeBtn.parentNode.insertBefore(successDiv, rechargeBtn);
    
    // 3秒后移除
    setTimeout(() => {
      if (successDiv.parentNode) {
        successDiv.parentNode.removeChild(successDiv);
      }
    }, 3000);
  }

  // 检查是否是首次安装
  checkFirstInstall() {
    const installKey = 'wx_query_tool_installed';
    const hasInstalled = localStorage.getItem(installKey);
    
    if (!hasInstalled) {
      // 标记为已安装
      localStorage.setItem(installKey, 'true');
      // 延迟显示欢迎弹窗
      setTimeout(() => {
        this.showWelcomeModal();
      }, 1000);
    }
  }

  // 显示欢迎弹窗
  showWelcomeModal() {
    const modal = document.createElement('div');
    modal.className = 'wx-query-modal wx-welcome-modal';
    modal.innerHTML = `
      <div class="wx-query-modal-content wx-welcome-content">
        <div class="wx-query-modal-header">
          <h3 class="wx-query-modal-title">欢迎使用微信公众号查询工具</h3>
          <button class="wx-query-close-btn wx-welcome-close-btn">&times;</button>
        </div>
        
        <div class="wx-welcome-body">
          <div class="wx-welcome-icon">
            <svg width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="#07c160" stroke-width="2">
              <circle cx="11" cy="11" r="8"></circle>
              <path d="m21 21-4.35-4.35"></path>
            </svg>
          </div>
          
          <div class="wx-welcome-text">
            <h4>🎉 安装成功！</h4>
            <p>感谢您安装微信公众号信息查询工具！</p>
            <div class="wx-welcome-features">
              <div class="wx-welcome-feature">
                <span class="wx-welcome-feature-icon">📊</span>
                <span>快速查询公众号粉丝数</span>
              </div>
              <div class="wx-welcome-feature">
                <span class="wx-welcome-feature-icon">🔍</span>
                <span>获取详细账号信息</span>
              </div>
              <div class="wx-welcome-feature">
                <span class="wx-welcome-feature-icon">⚡</span>
                <span>高效便捷的操作体验</span>
              </div>
            </div>
            <p class="wx-welcome-tip">
              💡 <strong>使用提示：</strong>在微信公众平台后台点击「对标信息」按钮即可开始使用
            </p>
          </div>
        </div>
        
        <div class="wx-welcome-footer">
          <button class="wx-welcome-start-btn">开始使用</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
    
    // 绑定事件
    const closeBtn = modal.querySelector('.wx-welcome-close-btn');
    const startBtn = modal.querySelector('.wx-welcome-start-btn');
    
    const closeModal = () => {
      modal.classList.remove('show');
      setTimeout(() => {
        document.body.removeChild(modal);
      }, 300);
    };
    
    closeBtn.addEventListener('click', closeModal);
    startBtn.addEventListener('click', closeModal);
    
    // 点击背景关闭
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        closeModal();
      }
    });
    
    // ESC关闭
    const escHandler = (e) => {
      if (e.key === 'Escape') {
        closeModal();
        document.removeEventListener('keydown', escHandler);
      }
    };
    document.addEventListener('keydown', escHandler);
    
    // 显示弹窗
    setTimeout(() => {
      modal.classList.add('show');
    }, 100);
  }

  // 显示查询结果
  showResult(account, detailData) {
    // 解析粉丝数
    let fansCount = '未知';
    try {
      if (detailData.publish_page) {
        const publishPage = JSON.parse(detailData.publish_page);
        if (publishPage.publish_list && publishPage.publish_list.length > 0) {
          const firstPublish = publishPage.publish_list[0];
          const publishInfo = JSON.parse(firstPublish.publish_info);
          if (publishInfo.sent_status && publishInfo.sent_status.total) {
            fansCount = publishInfo.sent_status.total.toLocaleString();
          }
        }
      }
    } catch (e) {
      // 解析粉丝数失败时使用默认值
    }

    const resultHtml = `
      <div class="wx-query-result">
        <div class="wx-query-result-title">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M9 11 12 14 22 4"></path>
            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
          </svg>
          查询结果
        </div>
        
        <div style="display: flex; align-items: flex-start; margin-bottom: 20px;">
          <img src="${account.round_head_img}" alt="头像" class="wx-query-avatar" />
          <div style="flex: 1;">
            <div class="wx-query-result-item">
              <span class="wx-query-result-label">公众号名称:</span>
              <span class="wx-query-result-value">${account.nickname}</span>
            </div>
            <div class="wx-query-result-item">
              <span class="wx-query-result-label">微信号:</span>
              <span class="wx-query-result-value">${account.alias || '未设置'}</span>
            </div>
          </div>
        </div>
        
        <div class="wx-query-result-item">
          <span class="wx-query-result-label">粉丝数:</span>
          <span class="wx-query-result-value" style="color: #07c160; font-weight: 600; font-size: 18px;">${fansCount}</span>
        </div>
        
        <div class="wx-query-result-item">
          <span class="wx-query-result-label">简介:</span>
          <span class="wx-query-result-value">${account.signature || '暂无简介'}</span>
        </div>
        
        <div class="wx-query-result-item">
          <span class="wx-query-result-label">认证状态:</span>
          <span class="wx-query-result-value">${account.verify_status === 0 ? '未认证' : '已认证'}</span>
        </div>
        
        <div class="wx-query-result-item">
          <span class="wx-query-result-label">账号类型:</span>
          <span class="wx-query-result-value">${account.service_type === 1 ? '订阅号' : '服务号'}</span>
        </div>
      </div>
    `;

    this.resultDiv.innerHTML = resultHtml;
  }
}

// 等待页面加载完成后初始化
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    new WeChatQueryTool();
  });
} else {
  new WeChatQueryTool();
}
