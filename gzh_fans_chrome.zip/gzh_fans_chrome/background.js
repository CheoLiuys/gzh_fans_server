// 微信公众号信息查询插件 - Background Script
// 插件作者「公众号：刘坏坏」

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getCookies') {
    chrome.cookies.getAll({url: 'https://mp.weixin.qq.com'}, (cookies) => {
      const cookieString = cookies.map(cookie => `${cookie.name}=${cookie.value}`).join('; ');
      sendResponse({cookies: cookieString});
    });
    return true; // 保持消息通道开放
  }
});
